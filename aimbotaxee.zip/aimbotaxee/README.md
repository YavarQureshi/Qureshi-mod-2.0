<h3>
  
[![Telegram Group](https://img.shields.io/badge/Telegram-Group-white?&style=social&logo=telegram)](https://t.me/+e2cJPMT6-LszODRl)
  [![Telegram Channel](https://img.shields.io/badge/Telegram-Channel-white?&style=social&logo=telegram)](https://t.me/jujutsukaisenaimbot)

</h3>
